# python-api
Python APIs to run Alogorithm 1 and Algorithm2 & Algorith3

# switch to virtual environment.
source venv/bin/active

cd to python_code.
# Instance: 139.59.80.148
# Algorithm 1 
export FLASK_APP=algo1_flask_app.py
pm2 start "flask run --host=139.59.80.148 --port=4657" --name algo1_flask_app
pm2 start "celery -A algo1_flask_app.celery worker -l info --without-gossip --without-mingle --without-heartbeat -Ofair" --name algo1_celery_api

# Algorithm 2
export FLASK_APP=algo2_flask_app.py
pm2 start "flask run --host=139.59.80.148 --port=4658" --name alog2_flask_app
pm2 start "celery -A algo2_flask_app.celery worker -l info --without-gossip --without-mingle --without-heartbeat -Ofair" --name algo2_celery_api

# Algorithm 3 4670
export FLASK_APP=algo3_flask_app.py
pm2 start "flask run --host=139.59.80.148 --port=4670" --name alog3_flask_app
pm2 start "celery -A algo3_flask_app.celery worker --loglevel=info -Q expqueue --without-gossip --without-mingle --without-heartbeat -Ofair" --name algo3_celery_api

@ Algorithm 4 4672
export FLASK_APP=algo4_flask_app.py
pm2 start "flask run --host=139.59.80.148 --port=4672" --name alog4_flask_app
pm2 start "celery -A algo4_flask_app.celery worker --loglevel=info -Q impuritycontrolqueue --without-gossip --without-mingle --without-heartbeat -Ofair" --name algo4_celery_api

# Mail server  port 4671
export FLASK_APP=mail_sender.py
pm2 start "flask run --host=139.59.80.148 --port=4671" --name mail_flask_app

# node js api
pm2 start "npm start" --name formdemapi

# Angular js API
pm2 start "http-server  adminpanel -p 4659" --name formdemui

# backup db
pg_dump -U postgres -d postgres -F c -f formdem-prod-sql.dump

restore:
pg_restore -U postgres -h [host] -d postgres -F c /tmp/formdem-prod-sql.dump
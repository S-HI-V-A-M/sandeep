## Importing required libraries/modules for stability score calculation ##
## Algorithm 2
from flask import Flask, jsonify, request
from celery import Celery
import numpy as np
import sys
import os
from celery.contrib import rdb
import requests
import json
import AES
from dotenv import load_dotenv

## Directory in which Python looks for modules for the stability score calculation ##
## Path needs to be replaced according to the modules availability ##
## python_engine_base_path = /home/chemistry2/ORCA/openCOSMO-RS_py/src
load_dotenv()
python_engine_base_path = os.getenv("PYTHON_ENGINE_PATH")
print('main python engine path =', python_engine_base_path)
formdem_api_base_url = os.getenv("FORMDEM_UI_URL")
print('formdem main base url = ', formdem_api_base_url)

sys.path.insert(0, python_engine_base_path)
from opencosmorspy.parameterization import Parameterization
from opencosmorspy.cosmors import COSMORS
from dotenv import load_dotenv
from base64 import b64decode

#############################################################
            # flask celery decorator #
#############################################################
app = Flask(__name__)
app.config["CELERY_BROKER_URL"] = "redis://localhost:6379/1"
app.config["CELERY_BACKEND_URL"] = "redis://localhost:6379/1"

validator=AES.LicenseValidator(secret_key=b64decode(os.getenv("SECRET_KEY")))

celery = Celery(app.name, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_BACKEND_URL"])
celery.conf.update(app.config)

#############################################################
                ## Stability score Calculation ##
#############################################################
@celery.task(name='calculate_activity_coefficient',bind=True) 
def calculate_activity_coefficient(self, input_data, temp_in_kelvin, rh_value, job_id):
    ### try/except - to handle algorithm failures ###s
    try:
        crs = COSMORS(par='default_orca')
        crs.par.calculate_contact_statistics_molecule_properties = True
        
        wt_fraction_list = []; molecule_list = [] ## weight_fraction_list_initialization ##
        for data in input_data:
            molecule_name = data["molecule_name"]
            wt_fraction = data["wt_fraction"]
            mol_structure_list = [sys.path[0]+"/opencosmorspy/"+molecule_name+"/COSMO_TZVPD/"+molecule_name+"_c000.orcacosmo"]
            crs.add_molecule(mol_structure_list)
            wt_fraction_list.append(float(wt_fraction))
            molecule_list.append(molecule_name)
        
        x = np.array(wt_fraction_list)
        T = float(temp_in_kelvin)
        crs.add_job(x, T, refst='pure_component')
        results = crs.calculate()
        
        print("Total logarithmic activity coefficient:", results['tot']['lng'])
        final_data = (results['tot']['lng']).tolist()

        task_id = calculate_activity_coefficient.request.id
        task_result_dict = process_task_result(molecule_list, final_data)
        try:
            post_task_result_to_db(task_id, job_id, "true", task_result_dict)
        except:
            return final_data
    except:
        task_id = calculate_activity_coefficient.request.id
        task_result_dict = []
        try:
            post_task_result_to_db(task_id, job_id, "false", task_result_dict)
        except:
            return task_result_dict
   
## processing celery task result - to send the stability score calc result to node in dictionary ##
def process_task_result(molecule_list, task_result):
    task_result_dict = []
    for i in range(0,len(task_result[0]),1):
        result_dict_each_molecule = {"m_name": molecule_list[i], "s_score": task_result[0][i]}
        task_result_dict.append(result_dict_each_molecule)
    return task_result_dict

## api end point to post stability score calculation result back to node.js ##
def post_task_result_to_db(task_id, job_id, stability_score_calc_status, task_result_dict):
    ## The Node API endpoint needs be updated to reflect the IP address and port number based on the system and port it is currently running on ## 
    url = formdem_api_base_url+"/callbackurl" 
    response = requests.post(url=url,data = json.dumps({"task_id" : task_id, "job_id" : job_id, "stability_score_calc_status": stability_score_calc_status, "result" : task_result_dict}),headers={"Content-Type": "application/json"}, timeout=10)
    return response

#######################################################################
                    ## FLASK APP ##
#######################################################################
@app.route("/activity_calculation_coefficient", methods = ['GET', 'POST'])
def wrapper_fn():
    
    ## WITH POST METHOD ##
    ### Receiving the inputs from node and decoding it ###
    data = request.get_json()
    job_id = data["job_id"]
    stability_score_temp = data["stability_score_temp"]
    stability_score_rh = data["stability_score_RH"]
    input_data = data["stability_score_list"]
        
    
    ## creating/scheduling celery task - calculate_activity_coefficient ##
    result = calculate_activity_coefficient.delay(input_data, stability_score_temp, stability_score_rh, job_id)
    
    ## creates a unique task id for the job submitted ## 
    return jsonify({'task_id': result.id})


if  __name__=='__main__':

    app.run(debug=True, port=4658)

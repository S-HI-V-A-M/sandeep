# get the drugexcipient calculations
from flask import Flask, jsonify, request
import sys
import os
import requests
import json
from dotenv import load_dotenv
import numpy as np
import traceback

load_dotenv()
python_engine_base_path = os.getenv("PYTHON_ENGINE_PATH")
print('main python engine path =', python_engine_base_path)
formdem_api_base_url = os.getenv("FORMDEM_UI_URL")
print('formdem main base url = ', formdem_api_base_url)

sys.path.insert(0, python_engine_base_path)
#from opencosmorspy import Parameterization, COSMORS
from opencosmorspy.parameterization import Parameterization
from opencosmorspy.cosmors import COSMORS

from flask import Flask, request
from celery import Celery, chain
from celery.contrib import rdb

app = Flask(__name__)
app.config["CELERY_BROKER_URL"] = "redis://localhost:6379/4"
app.config["CELERY_BACKEND_URL"] = "redis://localhost:6379/4"

celery = Celery(app.name, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_BACKEND_URL"])
celery.conf.update(app.config)

## api end point to post stability score calculation result back to node.js ##
def post_task_result_to_db(task_id, job_id, calc_status, task_result):
    ## The Node API endpoint needs be updated to reflect the IP address and port number based on the system and port it is currently running on ##
    url = formdem_api_base_url+"/impurityctrlcallback"
    print('call backurl =%s', url)
    response = requests.post(url=url,data = json.dumps({"task_id" : task_id, "job_id" : job_id, "calc_status": calc_status, "result" : task_result}),headers={"Content-Type": "application/json"}, timeout=10)
    return response

@celery.task(name='calculate_impurity_control', bind=True)
def calculate_impurity_control(self, data):
    '''
      method to calculate drug exp compatiblity
    '''   
    print('input data', data)
    job_id = data["job_id"]
    #api_name = data["api_name"]
    #exp_name = data["excipient_name"]
    #impurity_name = data["impurity_name"]
    temperature = data["temperature"]
    exp_weight_fraction = data['exp_weight_fraction']
    api_weight_fraction = data['api_weight_fraction']
    imp_weight_fraction = data['imp_weight_fraction']
    body_data = data['data']

    print('body data.................', body_data)

    print('exp weight fraction==',exp_weight_fraction)
    print('api_wight fraction ==', api_weight_fraction)
    print('impurity_wight fraction ==', imp_weight_fraction)
    
    lac_result = []
    try:
        for entry in data['data']:
            api_name = entry['api_name']
            exp_name = entry['exp_name']
            imp_name = entry['imp_name']
            exp_wf = entry['exp_wf']
            
            print(f"API Name: {api_name}, Exp Name: {exp_name}, Imp Name: {imp_name}, Exp WF: {exp_wf}")
            crs = COSMORS(par='default_orca')
            crs.par.calculate_contact_statistics_molecule_properties = True
            # API Input
            mol_structure_list_0 = [python_engine_base_path+'/opencosmorspy/'+ api_name + '/COSMO_TZVPD/' + api_name + '_c000.orcacosmo'] 
            crs.add_molecule(mol_structure_list_0)
            crs.add_molecule([python_engine_base_path+'/opencosmorspy/'+ exp_name + '/COSMO_TZVPD/' + exp_name + '_c000.orcacosmo'])
            x = np.array([float(api_weight_fraction),float(exp_weight_fraction)])
            T = ''
            if temperature == 45:
                T = 318.15
            elif temperature == 25:
                T = 298.15
            else:
                print('invalid temperature')

            crs.add_job(x, T, refst='pure_component')
            results = crs.calculate()

            coe_arr = np.array(results['tot']['lng'])
            
            # API - First Value in the array
            RE2 = coe_arr[0,0]
            print('RE2: ', RE2)
            
            # Second COSMORS object  Impurity Control
            crs = COSMORS(par='default_orca')
            crs.par.calculate_contact_statistics_molecule_properties = True
            mol_structure_list_1 = ([python_engine_base_path+'/opencosmorspy/'+ imp_name + '/COSMO_TZVPD/' + imp_name + '_c000.orcacosmo'])
            crs.add_molecule(mol_structure_list_1)
            crs.add_molecule([python_engine_base_path+'/opencosmorspy/'+ exp_name + '/COSMO_TZVPD/' + exp_name + '_c000.orcacosmo'])
            x = np.array([float(imp_weight_fraction),float(exp_weight_fraction)])

            crs.add_job(x, T, refst='pure_component')
            results_t = crs.calculate()

            coe_arr_t = np.array(results_t['tot']['lng'])
            RE3 = coe_arr_t[0,0]
           
            print('RE3 ', RE3)
           
            # Calculate and print the difference
            temp_obj = {
                'excepname': exp_name,
                'impname': imp_name,
                'RE1': RE3 - RE2,
                'RE2': RE2,
                'RE3': RE3
            }
            print('RE_temp:', temp_obj)
            lac_result.append(temp_obj)

        print('The total calculated object = %s', lac_result)
        task_id = calculate_impurity_control.request.id
        print('task id', task_id)
        try:
            post_task_result_to_db(task_id, job_id, "true", lac_result)
            print('after posting')
        except:
            return lac_result
    except Exception:
        print('inside first try ===',traceback.format_exc())
        task_id = calculate_impurity_control.request.id
        iac_result = []
        try:
            print('in side the second try ===',traceback.format_exc())
            if len(lac_result) >= 1:
                post_task_result_to_db(task_id, job_id, "true", lac_result)
            else:
                post_task_result_to_db(task_id, job_id, "false", lac_result)
        except:
            return lac_result


@app.route("/impuritycontrol", methods = ['POST'])
def exp_calculator():
    data = request.get_json()
    
    task = calculate_impurity_control.apply_async(args=[data], queue='impuritycontrolqueue')
    #return jsonify({'status': 'Task submitted'})
    return jsonify({'task_id': task.id, 'status': 'Task submitted'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4672)

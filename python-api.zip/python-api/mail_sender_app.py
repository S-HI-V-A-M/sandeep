import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Flask, jsonify, request
from werkzeug.utils import secure_filename
from flask_cors import CORS, cross_origin
app = Flask(__name__)
import AES
from base64 import b64decode
import os, shutil
from dotenv import load_dotenv

# ... (rest of your code)
load_dotenv()
UPLOAD_FOLDER = os.getenv("UPLOADS_FOLDER")
ALLOWED_EXTENSIONS = {'txt'}

validator=AES.LicenseValidator(secret_key=b64decode(os.getenv("SECRET_KEY")))
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
CORS(app, support_credentials=True)
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/check-license", methods=['POST'])
def check_license():
    license_key_file = request.files["license_key_file"]
    license_file = request.files["license"]
    user_id = request.form["user_id"]

    if 'license_key_file' not in request.files or 'license' not in request.files:
        return {"message": "Missing file"}, 400

    if license_key_file.filename == '' or license_file.filename == '':
        return {"message": "No selected file"}, 400

    if not user_id:
        return {"message": "User id not provide"}, 400

    if license_key_file and allowed_file(license_key_file.filename) and license_file and allowed_file(license_file.filename):
        # Save uploaded files to the designated folder
        licence_file_key_file_path = os.path.join(app.config['UPLOAD_FOLDER'], user_id)
        if os.path.exists(licence_file_key_file_path):
            shutil.rmtree(licence_file_key_file_path)

        if not os.path.exists(licence_file_key_file_path):
            os.makedirs(licence_file_key_file_path)

        license_key_filename = secure_filename(license_key_file.filename)
        license_filename = secure_filename(license_file.filename)

        license_key_filename = f"{license_key_filename.split('.')[0]}___key.{license_key_filename.split('.')[-1]}"
        license_filename = f"{license_filename.split('.')[0]}___val.{license_filename.split('.')[-1]}"

        license_key_file.save(os.path.join(licence_file_key_file_path, license_key_filename))
        license_file.save(os.path.join(licence_file_key_file_path, license_filename))

        license_key_file.close()
        license_file.close()
        
        license_key_text_file = open(os.path.join(licence_file_key_file_path, license_key_filename), "r")
        
        license_file_text_file = open(os.path.join(licence_file_key_file_path, license_filename), "r")
        
        # Perform license validation
        validation_details = validator.is_license_valid(license_file_text_file, license_key_text_file.read(),os.path.join(licence_file_key_file_path, license_key_filename))
        if (validation_details["validity"]==True):
            return {"message": "License is valid",
                    "license_duration": validation_details["license_duration"],
                    }, 200
        else:
            return {"message": "License is invalid"}, 400
    else:
        return {"message": "Invalid file extension"}, 400
    
@app.route("/check-license-validity", methods=['GET'])
def checkLicenseValidity():
    user_id = request.args.get("user_id")
    if not user_id:
        return {"message": "User ID not provided"}, 400

    licence_file_key_file_path = os.path.join(app.config['UPLOAD_FOLDER'], user_id)
    if not os.path.exists(licence_file_key_file_path):
        return {'message': "License is not provided! first upload the file."}, 400

    all_files = os.listdir(licence_file_key_file_path)
    license_filename = ''
    license_key_filename = ''
    for file_name in all_files:
        if file_name.split('.')[0][-6:] == '___val':
            license_filename = file_name
        if file_name.split('.')[0][-6:] == '___key':
            license_key_filename = file_name

    if license_key_filename == '' or license_filename == '':
        return {"message": "No selected file"}, 400
    
    license_key_text_file = open(os.path.join(licence_file_key_file_path, license_key_filename), "r")
        
    license_file_text_file = open(os.path.join(licence_file_key_file_path, license_filename), "r")
    
    # Perform license validation
    validation_details = validator.is_license_valid(license_file_text_file, license_key_text_file.read(),os.path.join(licence_file_key_file_path, license_key_filename))
    if (validation_details["validity"]==True):
        return {"message": "License is valid",
                "license_duration": validation_details["license_duration"],
                }, 200
    else:
        return {"message": "License is invalid"}, 400


def send_mail(sender_email, receiver_email, smtp_server, smtp_port, username, password, data):
    message_1 = MIMEMultipart()
    message_1['From'] = sender_email
    message_1['To'] = receiver_email
    message_1['Subject'] = 'Details of user '+data['name']
    message_1['Cc']="ravisa@pharmadem.in,ravip@pharmadem.in"

    body = f"Name: {data['name']}\nEmail: {data['email']}\nPhone: {data['phone']}\nCompany Name: {data['company_name']}\nLicense Type: {data['license_type']}\nLicense Duration: {data['license_duration']}\nMac Address: {data['mac_address']}\nPurpose: {data['purpose']}"

    message_1.attach(MIMEText(body, 'plain'))
    
    message_2=MIMEMultipart()
    
    message_2['From'] = sender_email
    message_2['To'] = data['email']
    message_2['Subject'] = 'Confirmation Mail'
    
    body="""One of our representatives will get back to you shortly to address your questions and provide any additional information you may need. If you have any urgent matters, please feel free to contact us directly at enquiry@pharmadem.in
            We look forward to the opportunity to assist you further and provide the information you are seeking.
            Best Regards,
            Team PharmaDEM"""

    context = ssl.create_default_context()

    with smtplib.SMTP_SSL(smtp_server, smtp_port, context=context) as server:
        server.login(username, password)
        server.sendmail(sender_email, receiver_email, message_1.as_string())
        server.sendmail(sender_email, data['email'], message_2.as_string())

@app.route("/submit-information", methods=['POST'])
def submit_information():
    sender_email = 'enquiry@pharmadem.in'
    receiver_email = 'enquiry@pharmadem.in'
    smtp_server = 'mail.pharmadem.in'
    smtp_port = 465
    username = 'enquiry@pharmadem.in'
    password = 'Ravi@123456'

    data = request.get_json()
    name = data["name"]
    email = data["email"]
    phone = data["phone"]
    company_name = data["company_name"]
    license_type = data["license_type"]
    license_duration = data["license_duration"]
    mac_address = data["mac_address"]
    purpose = data["purpose"]

    if (email == "" or name == "" or phone == "" or company_name == "" or license_type == "" or license_duration == "" or purpose == ""):
        return {"message": "Please fill all the fields"}, 400

    send_mail(sender_email, receiver_email, smtp_server, smtp_port, username, password, data)

    return {"message": "success"}, 200

# ... (rest of your code)

if __name__ == '__main__':
    app.run(debug=True, port=4671)

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from base64 import b64encode, b64decode
import time
import datetime
import uuid
import os
from dotenv import load_dotenv
from uuid import getnode as get_mac
from dateutil import parser

class LicenseValidator:
    def __init__(self, secret_key):
        self.secret_key = secret_key

    def get_system_time(self):
        return datetime.datetime.utcnow()

    def get_internet_time(self):
        # Placeholder for fetching time from the internet
        return self.get_system_time()

    def get_device_mac_address(self):
        mac=get_mac()
        ms=':'.join(("%012X" % mac)[i:i+2] for i in range(0, 12, 2))
        return ms

    def get_file_mac_address(self, file_path):
        try:
            with open(file_path, 'rb') as file:
                file_content = file.read()
                decrypted_file_content = self.decrypt_license(file_content.decode('utf-8'))
                mac_address = decrypted_file_content.split("$")[3]
                return mac_address
        except FileNotFoundError:
            return None

    def encrypt_license(self, license_key):
        secret_key = bytes(self.secret_key, 'utf-8')
        license_bytes = bytes(license_key, 'utf-8')
        iv = b'\x00' * 16  # For simplicity, you may use a random IV in a real-world scenario
        cipher = Cipher(algorithms.AES(secret_key), modes.CFB(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        creation_timestamp = time.mktime(time.gmtime())
        encrypted_license = encryptor.update(license_bytes) + encryptor.finalize()
        return b64encode(encrypted_license + creation_timestamp.to_bytes(8, byteorder='big')).decode('utf-8')

    def is_license_valid(self, license_key, encrypted_data, file_path):
        license_details=license_key.readlines()
        
        system_time = self.get_system_time()
        internet_time = self.get_internet_time()
        device_mac_address = license_details[5].split("=")[1].strip()
        file_mac_address = self.get_file_mac_address(file_path)

        time_difference_threshold = datetime.timedelta(seconds=5)
        if abs(system_time - internet_time) > time_difference_threshold:
            print("System time and internet time are not in sync")
            return {"validity":False}
        
        print("Device MAC address: " + str(device_mac_address))
        
        print("File MAC address: " + str(file_mac_address))

        if device_mac_address != file_mac_address:
            print("Device MAC address and file MAC address do not match")
            return {"validity":False}

        

        decrypted_data = self.decrypt_license(encrypted_data).split("$")
        
        input_date = parser.parse(decrypted_data[-1])

        # Get the current date and time
        current_date = datetime.datetime.now()

        # Calculate the difference between the input date and the current date
        difference = current_date - input_date
        
        print(decrypted_data)
        if(difference >= datetime.timedelta(days=int(decrypted_data[-3]))):
            print("License is invalid")
            print("License expired")
            return {"validity":False,
                    "license_duration":0}
        
        print("System time: " + str(system_time))
        print("Internet time: " + str(internet_time))
        print("Device MAC address: " + str(device_mac_address))
        print("File MAC address: " + str(file_mac_address))
        print("Time difference threshold: " + str(time_difference_threshold))
        print("License key: " + str(license_key))
        print("Number of days remaining in license "+ str(int(decrypted_data[-3])-difference.days))
        

            
        
        return {"validity":decrypted_data[4] == license_details[4].split("=")[1].strip(),
                "license_duration":str(int(decrypted_data[-3])-difference.days)}

    def validate_license(self):
        if(self.is_license_valid(self.lic_key.readlines()[4].split("=")[1].strip(), self.lic_check.read(), "license.txt")== True):
            print("License is valid")
            return True
        else:
            print("License is invalid")
            return False

    def decrypt_license(self, encrypted_data):
        key_bytes = self.secret_key
        secret_key_bytes = key_bytes[:16]  # Ensure the key is the correct length (16 bytes)
        cipher = Cipher(algorithms.AES(secret_key_bytes), modes.ECB())
        decryptor = cipher.decryptor()

        decrypted_data = ""
        for encrypted_field in encrypted_data.split("$"):
            encrypted_bytes = b64decode(encrypted_field)
            decrypted_bytes = decryptor.update(encrypted_bytes)
            unpadder = padding.PKCS7(128).unpadder()
            decrypted_data += (unpadder.update(decrypted_bytes) + unpadder.finalize()).decode('utf-8') + "$"


        return decrypted_data[:-1]










# get the drugexcipient calculations
from flask import Flask, jsonify, request
import sys
import os
import requests
import json
from dotenv import load_dotenv
import numpy as np
import traceback

load_dotenv()
python_engine_base_path = os.getenv("PYTHON_ENGINE_PATH")
print('main python engine path =', python_engine_base_path)
formdem_api_base_url = os.getenv("FORMDEM_UI_URL")
print('formdem main base url = ', formdem_api_base_url)

sys.path.insert(0, python_engine_base_path)
#from opencosmorspy import Parameterization, COSMORS
from opencosmorspy.parameterization import Parameterization
from opencosmorspy.cosmors import COSMORS

from flask import Flask, request
from celery import Celery, chain
from celery.contrib import rdb

app = Flask(__name__)
app.config["CELERY_BROKER_URL"] = "redis://localhost:6379/3"
app.config["CELERY_BACKEND_URL"] = "redis://localhost:6379/3"

celery = Celery(app.name, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_BACKEND_URL"])
celery.conf.update(app.config)

## api end point to post stability score calculation result back to node.js ##
def post_task_result_to_db(task_id, job_id, calc_status, task_result):
    ## The Node API endpoint needs be updated to reflect the IP address and port number based on the system and port it is currently running on ##
    url = formdem_api_base_url+"/drugexpcallback"
    print('call backurl =%s', url)
    response = requests.post(url=url,data = json.dumps({"task_id" : task_id, "job_id" : job_id, "calc_status": calc_status, "result" : task_result}),headers={"Content-Type": "application/json"}, timeout=10)
    return response

@celery.task(name='calculate_drug_execp_compatibility', bind=True)
def calculate_drug_execp_compatibility(self, data):
    '''
      method to calculate drug exp compatiblity
    '''   
    
    job_id = data["job_id"]
    api_name = data["api_name"]
    api_demfile= data['api_demfile']
    temperature = data["temperature"]
    exp_weight_fraction = data['exp_weight_fraction']
    api_weight_fraction = data['api_weight_fraction']
    exp_data = data['exp_list']

    print('exp weight fraction==',exp_weight_fraction)
    print('api_wight fraction ==', api_weight_fraction)
    #print('existing_exp_list', exp_data['existingNames'])
    exp_list = exp_data['existingNames']
    print('exp list', exp_list)

    exp_map = exp_data['mappedResults']
    print('the excep map =', exp_map)
    #exp_list = ['PEG_300', 'Croscarmellose_sodium', 'Carbopol_934', 'PEG_300', 'Agar', 'Carnauba_wax', 'Copovidone', 'Croscarmellose_sodium', 'EthylCellulose', 'Docosanol', 'Dextrin', 'Isopropyl_isostearate', 'Isopropyl_stearate', 'Hypromellose', 'Hydroxypropyl_cellulose', 'Glyceryl_dibehenate', 'Glucose', 'Glyceryl_Behenate', 'Hydroxyethyl_cellulose', 'Lactose', 'Guar_gum', 'Docosanol', 'Methacrylicacid_ethylacrylate_copolymer', 'Calcium_lactate', 'Croscarmellose_sodium', 'Dextrate', 'Dextrin', 'Hydroxyethylmethyl_cellulose', 'Docosanol', 'Hydroxypropyl_starch', 'Glucose', 'Polycarbophil', 'Aluminium_silicate', 'Alginic_acid', 'Alginic_acid', 'Calcium_lactate', 'Lactose', 'Carbopol_934', 'Calcium_carboxymethylcellulose', 'Calcium_lactate', 'Gelatin_part2', 'Lactose', 'Magnesium_hydroxide', 'Glucose', 'PEG4000', 'Lactose']

    try:
        crs = COSMORS(par='default_orca')
        crs.par.calculate_contact_statistics_molecule_properties = True
        mol_structure_list_0 = [python_engine_base_path+'/opencosmorspy/'+ api_name + '/COSMO_TZVPD/' + api_demfile] 
        crs.add_molecule(mol_structure_list_0)
        lac_result = []
        T  = ''
        coe_empty = []
        for result in exp_map:
            excipient_name = result['excipientname']
            excep_id = result['excipient_id']
            print('Excipient name =', excipient_name)
            crs = COSMORS(par='default_orca')
            crs.par.calculate_contact_statistics_molecule_properties = True
            crs.add_molecule(mol_structure_list_0)
            molecule_result = {}
            dem_folder_name = excipient_name
            print('dem folder name = %s', dem_folder_name)
            crs.add_molecule([python_engine_base_path+'/opencosmorspy/'+ dem_folder_name + '/COSMO_TZVPD/' + excipient_name +'_c000.orcacosmo'])
            x = np.array([float(api_weight_fraction),float(exp_weight_fraction)])
        
            if temperature == 45:
                T = 318.15
            elif temperature == 25:
                T = 298.15
            else:
                print('invalid temperature')
    
            crs.add_job(x, T, refst='pure_component')
            results = crs.calculate()
            arr = np.array(results['tot']['lng'])
            coe_value =  arr[0,0]
            molecule_result = {}
            if coe_value is not None:
               molecule_result = {
                  "molecule_name": excipient_name,
                  "excipientid": excep_id,
                  "logarithmic_act_coefficient": coe_value
               }
            else:
               molecule_result = {
                   "molecule_name": excipient_name,
                   "excipientid": excep_id,
                   "logarithmic_act_coefficient": coe_value
               }
               coe_empty.appened(molecule_result)

            lac_result.append(molecule_result)
            print('Total logarithmic activity coefficient for ', excipient_name , '=' , coe_value)

        print('total results = ', lac_result)
        print('failed exp list =', coe_empty)
        task_id = calculate_drug_execp_compatibility.request.id
        print('task id', task_id)
        try:
            post_task_result_to_db(task_id, job_id, "true", lac_result)
            print('after posting')
        except:
            return lac_result
    except Exception:
        print('inside first try ===',traceback.format_exc())
        task_id = calculate_drug_execp_compatibility.request.id
        iac_result = []
        try:
            print('in side the second try ===',traceback.format_exc())
            if len(lac_result) >= 1:
                post_task_result_to_db(task_id, job_id, "true", lac_result)
            else:
                post_task_result_to_db(task_id, job_id, "false", lac_result)
        except:
            return lac_result


@app.route("/calculatedrugexp/", methods = ['POST'])
def exp_calculator():
    data = request.get_json()
    print('input data', data)

    task = calculate_drug_execp_compatibility.apply_async(args=[data], queue='expqueue')
    return jsonify({'task_id': task.id, 'status': 'Task submitted'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=4670)

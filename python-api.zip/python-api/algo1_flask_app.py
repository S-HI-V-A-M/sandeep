## Importing required libraries/modules for Task-1 DEM file creation ##
## Algorithm 1
import csv 
import os
import sys
import AES
from dotenv import load_dotenv
from base64 import b64decode
import shutil
## Directory in which Python looks for modules for DEM file creation ## 
## Path needs to be replaced according to the modules availability ##
## python_engine_base_path = /home/chemistry2/ORCA/openCOSMO-RS_py/src
## formdem_api_base_url= http://164.52.216.127:1086/api
load_dotenv()
python_engine_base_path = os.getenv("PYTHON_ENGINE_PATH")
print('main python engine path =', python_engine_base_path)
formdem_api_base_url = os.getenv("FORMDEM_UI_URL")
print('formdem main base url = ', formdem_api_base_url)
sys.path.insert(0, python_engine_base_path+'/opencosmorspy/')
from ConformerGenerator_check import ConformerGenerator, ORCA_XTB2_ALPB, ORCA_DFT_CPCM_FAST, ORCA_DFT_CPCM_FINAL, kJ_per_kcal

## Importing required libraries/modules for Task-2 ##
import sys
import requests
import json
import numpy as np
## Directory in which Python looks for modules for the stability score calculation ##
## Path needs to be replaced according to the modules availability ##
sys.path.insert(0, python_engine_base_path)
from parameterization import Parameterization
from cosmors import COSMORS

#############################################################
            # flask celery decorator #
#############################################################
from flask import Flask, jsonify, request
from celery import Celery, chain
from celery.contrib import rdb

import smtplib,ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.config["CELERY_BROKER_URL"] = "redis://localhost:6379/2"
app.config["CELERY_BACKEND_URL"] = "redis://localhost:6379/2"

print('SecretKey for AES =', os.getenv("SECRET_KEY"))
validator=AES.LicenseValidator(secret_key=b64decode(os.getenv("SECRET_KEY")))

celery = Celery(app.name, broker=app.config["CELERY_BROKER_URL"], backend=app.config["CELERY_BACKEND_URL"])
celery.conf.update(app.config)

############################################################
             ## TASK 1 DEM file creation ##
############################################################
@celery.task(name='oc_file_creation', bind=True)
def oc_file_creation(self, inp_file, job_id):
    
    structures_file = inp_file
    n_cores = 16

    task_id = oc_file_creation.request.id
    
    name_smiles_dct = {}
    
    with open(sys.path[1]+structures_file, 'r') as f:
        
        reader = csv.reader(f, delimiter='\t')
        for line in reader:
            if len(line) == 3:
                SMILES = line[1]
                name_smiles_dct[line[0]] = (SMILES, int(line[2]))
    
    ### try/except - to handle algorithm failures ###
    try:
        ### The path needs to be overwritten before creating the DEM files because there are instances where the algorithm breaks and becomes stuck, ###
        ### such as in this example path: "/home/chemistry2/ORCA/openCOSMO-RS_py/src/opencosmorspy/hydrochloric_acid/" and it does not exit properly.###
        os.chdir(python_engine_base_path+'/opencosmorspy/')
        for name, (smiles, charge) in name_smiles_dct.items():
            
            print(f'starting: {name}')
            
            with ConformerGenerator(name, smiles, charge, n_cores=n_cores) as cg:
                
                n = cg.calculate_rdkit(rms_threshold=1.0)

                method = ORCA_XTB2_ALPB('water')
                cg.calculate_orca(method)

                cg.sort_by_energy()

                cg.filter_by_energy_window(6 * kJ_per_kcal)

                cg.filter_by_rms_window(rms_threshold=1.0)
            
                method = ORCA_DFT_CPCM_FAST()
                cg.calculate_orca(method)

                cg.filter_by_function(lambda _: [0])

                method = ORCA_DFT_CPCM_FINAL()
                cg.calculate_orca(method)

                cg.save_to_disk(save_xyz_file=False, save_attached_file=True)
                cg.copy_output(os.path.join(cg.dir_job, 'COSMO_TZVPD'), ['*.xyz'])

                print(f'finished: {name}')
                print()

        print('\nLa fin')
        return "completed", task_id
    except:
        return "failed", task_id
    
#############################################################
                ## TASK 2 Stability score Calculation ##
#############################################################
## api end point to post dem file creation status back to node.js ##
def post_first_task_result_to_db(dem_file_generation_status, job_id, task_id):
    ## The Node API endpoint needs be updated to reflect the IP address and port number based on the system and port it is currently running on ## 
    url = formdem_api_base_url+"/demfilecallback"
    response = requests.post(url=url,data = json.dumps({"job_id" : job_id, "task_id" : task_id, "dem_file_generation_status" : dem_file_generation_status}),headers={"Content-Type": "application/json"}, timeout=10)
    return response

## processing celery task result - to send the stability score calc result in dictionary ##
def process_task_result(molecule_list, result):
    task_result_dict = []
    for i in range(0,len(result[0]),1):
        result_dict_each_molecule = {"m_name": molecule_list[i], "s_score": result[0][i]}
        task_result_dict.append(result_dict_each_molecule)
    return task_result_dict

## api end point to post stability score calculation result back to node.js ##
def post_task_result_to_db(task_id, job_id, stability_score_calc_status, task_result_dict):
    ## The Node API endpoint needs be updated to reflect the IP address and port number based on the system and port it is currently running on ## 
    url = formdem_api_base_url+"/callbackurl"
    response = requests.post(url=url,data = json.dumps({"task_id" : task_id, "job_id" : job_id, "stability_score_calc_status": stability_score_calc_status, "result" : task_result_dict}),headers={"Content-Type": "application/json"}, timeout=10)
    return response

@celery.task(name='calculate_activity_coefficient',bind=True)
def calculate_activity_coefficient(self, algo_1_status, input_data, temp_in_kelvin, rh_value, job_id):
    ### DEM file creation status ##
    if(algo_1_status[0] == "completed"):
        dem_file_generation_status = "true"
    else:
        dem_file_generation_status = "false"
    
    task_id = algo_1_status[1]
    try:
        post_first_task_result_to_db(dem_file_generation_status, job_id, task_id)
    except:
        print("Algo 1 result posted")

    ## If DEM file creation succeeds, it will move to stability score calculation ##
    if (dem_file_generation_status == "true"):
        ### try/except - to handle algorithm failures ###
        try:
            crs = COSMORS(par='default_orca')
            crs.par.calculate_contact_statistics_molecule_properties = True

            wt_fraction_list = []; molecule_list = [] ## weight_fraction_list_initialization ##
            for data in input_data:
                molecule_name = data["molecule_name"] 
                wt_fraction = data["wt_fraction"]
                mol_structure_list = [sys.path[1]+molecule_name+"/COSMO_TZVPD/"+molecule_name+"_c000.orcacosmo"]
                crs.add_molecule(mol_structure_list)
                wt_fraction_list.append(float(wt_fraction))
                molecule_list.append(molecule_name)

            x = np.array(wt_fraction_list)
            T = float(temp_in_kelvin)
            crs.add_job(x, T, refst='pure_component')
            results = crs.calculate()
            print("Total logarithmic activity coefficient:", results['tot']['lng'])
            final_data = (results['tot']['lng']).tolist()

            task_id = calculate_activity_coefficient.request.id
            task_result_dict = process_task_result(molecule_list, final_data)
            try:
                post_task_result_to_db(task_id, job_id, "true", task_result_dict)
            except:
                return final_data
        except:
            task_id = calculate_activity_coefficient.request.id
            task_result_dict = []
            try:
                post_task_result_to_db(task_id, job_id, "false", task_result_dict)
            except:
                return task_result_dict
    else:
        return "process failed"

#######################################################################
                    ## FLASK APP ##
#######################################################################
@app.route("/combined_algorithm", methods = ['GET', 'POST'])
def wrapper_fn():
        
    ## WITH POST METHOD ##
    ### Receiving the inputs from node and decoding it ###
    data = request.get_json()
    job_id = data["job_id"]
    input_for_algo_1 = data["demfiles_list"]
    stability_score_temp = data["stability_score_temp"]
    stability_score_rh = data["stability_score_RH"]
    input_for_algo_2 = data["stability_score_list"]
    
    if(validator.validate_license()==False):
        return jsonify({"message":"License is invalid"})
    
    ## inp file creation - Opted for UUID for file naming ##
    import uuid
    unique_file_name = str(uuid.uuid4())
    inp_file_name = unique_file_name + ".inp"
    print("inp file name:", inp_file_name)
    ### writing the required inputs to the inp file ###
    with open(inp_file_name, "w") as f:
        for excipient_data in input_for_algo_1:
            f.write(excipient_data["molecule_name"] + "\t" + excipient_data["smiles_notation"] + "\t" + str(excipient_data["charge"]) + "\n")

    # added dem file copy to the propert destination.
    path = os.getcwd()
    print('current file path', path)
    # copy generated inp to the /home/chemistry1/einnel/opencosmos/openCOSMO-RS_py/src/opencosmorspy/
    script_home_path = python_engine_base_path+ '/opencosmorspy/'
    src_file_path = path+'/'+inp_file_name
    print('src file path', src_file_path)
    shutil.copy(src_file_path, script_home_path)

    ## creating/scheduling celery task - calculate_activity_coefficient should execute after oc_file_creation has completed ##
    result = (oc_file_creation.s(inp_file_name, job_id) | calculate_activity_coefficient.s(input_for_algo_2, stability_score_temp, stability_score_rh, job_id)).apply_async()

    ## creates a unique task id for the job submitted. first_task_id=DEM file creation, second_task_id=stability score calc ##
    return jsonify({'first_task_id': result.parent.id, 'second_task_id': result.id})


if __name__ == '__main__':

    app.run(debug=True, port=4657)